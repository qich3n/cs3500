# HW4

The current setup:

Model:
1. modelSize    : holds the modelSize for border control
2. shapeList    : holds all the shapes currently in the animation
3. log          : keeps track of all the modifications
4. operationList    : holds all the operations currently in the animation 

Model changes shapes by adding shapes and operations to itself. Can also remove the
shapes and operations when needed. The controller will handle resetting the animation
to include these changes made by the user. Then, to execute the operations, the function 
executeOperations is used. For now, nothing checks for the current time, it just runs 
all the operations currently listed in the operation list. In the next assignment, we will 
add a parameter to executeOperations that takes in the current time, and will only execute 
the operations that match this time.
When a shape is removed from the model, the log of this shape is removed, as well as any operations 
that worked on this shape.

Operations:
1. Each have a shapeName
2. Start time and start state (state is checked with the actual state of the shape to make sure 
   everything matches and is correct)
3. End time and end state
4. Have an execute function : takes in a shape and the modelSize and is abstract
5. Different operation objects : SizeOperation, ColorOperation, PositionOperation, 
   RotationOperation each with their own execute functions
   
Ensure that the operations are valid and don't go out of bounds (might change later depending
on if we want to have shapes exist outside the visible window)

Shape:
1. Is mutable (might change later)
2. has position, size, rotation, color
3. setters and getters for the parameters
4. getType to determine the name of the shape (circle, square, etc)

Different shape objects include Circle, Square, Rectangle, Hexagon, Oval, Triangle
Each of these extend an abstract class but have their getType and execute defined 
within them because these are unique to the specific class.


