package model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;

import cs3500.animator.model.Position2D;

/**
 * Tests for the operations in the Position2D class.
 */
public class Position2DTest {

  Position2D pos1;
  Position2D pos2;
  Position2D pos3;
  Position2D pos4;

  @Before
  public void setup() {
    pos1 = new Position2D(0, 30);
    pos2 = new Position2D(100,-2);
    pos3 = new Position2D(-10, 23);
    pos4 = new Position2D(100,-2);
  }

  @Test
  public void testPositionGetXGetY() {
    assertEquals(0, pos1.getX());
    assertEquals(30, pos1.getY());

    assertEquals(100, pos2.getX());
    assertEquals(-2, pos2.getY());

    assertEquals(-10, pos3.getX());
    assertEquals(23, pos3.getY());
  }

  @Test
  public void testPositionToString() {
    assertEquals("(0, 30)", pos1.toString());
    assertEquals("(100, -2)", pos2.toString());
    assertEquals("(-10, 23)", pos3.toString());
    assertEquals("(100, -2)", pos4.toString());
  }

  @Test
  public void testPositionEquals() {
    assertEquals(pos2, pos4);
    assertEquals(new Position2D(0, 30), pos1);
    assertNotEquals(pos3, pos4);
    assertNotEquals(pos1, pos3);
    assertNotEquals(new Position2D(0, 20), pos1);
  }

  @Test
  public void testPositionHashCode() {
    assertEquals(991, pos1.hashCode());
    assertEquals(4059, pos2.hashCode());
    assertEquals(674, pos3.hashCode());
    assertEquals(4059, pos4.hashCode());
    assertNotEquals(pos1.hashCode(), pos4.hashCode());
    assertEquals(pos4.hashCode(), pos2.hashCode());
  }

}
