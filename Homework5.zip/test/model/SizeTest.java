package model;

import org.junit.Before;
import org.junit.Test;

import cs3500.animator.model.Size;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Tests methods found in the Size class.
 */
public class SizeTest {
  Size s;
  Size s2;
  Size s3;

  @Before
  public void setUp() {
    s = new Size(10, 20);
    s2 = new Size(20, 40);
    s3 = new Size(50, 100);
  }

  @Test
  public void testConstructor() {
    try {
      s = new Size(0, 40);
    } catch (IllegalArgumentException a) {
      //test passes
      assertEquals("Size cannot be 0 or negative", a.getMessage());
    }

    try {
      s = new Size(10, -40);
    } catch (IllegalArgumentException a) {
      //test passes
      assertEquals("Size cannot be 0 or negative", a.getMessage());
    }
  }

  @Test
  public void testGetWidth() {
    assertEquals(10, s.getWidth());
    assertEquals(20, s2.getWidth());
    assertEquals(50, s3.getWidth());
  }

  @Test
  public void testGetHeight() {
    assertEquals(20, s.getHeight());
    assertEquals(40, s2.getHeight());
    assertEquals(100, s3.getHeight());
  }

  @Test
  public void testEquals() {
    assertEquals(s, new Size(10, 20));
    assertEquals(s2, new Size(20, 40));
    assertEquals(s3, new Size(50, 100));

    assertNotEquals(s, new Size(20, 20));
    assertNotEquals(s2, new Size(20, 30));
    assertNotEquals(s3, new Size(20, 10));

  }

}