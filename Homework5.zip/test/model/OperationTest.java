package model;

import static org.junit.Assert.assertEquals;

import java.awt.Color;

import cs3500.animator.model.Position2D;
import cs3500.animator.model.Size;
import cs3500.animator.model.shapes.Circle;
import cs3500.animator.model.operations.ColorOperation;
import cs3500.animator.model.operations.Operation;
import cs3500.animator.model.operations.PositionOperation;
import cs3500.animator.model.shapes.Rectangle;
import cs3500.animator.model.operations.RotationOperation;
import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.operations.SizeOperation;
import cs3500.animator.model.shapes.Triangle;
import org.junit.Test;

/**
 * Tests for the methods found in the Operation interface.
 */
public class OperationTest {

  //RotationOperation Constructors
  @Test(expected = IllegalArgumentException.class)
  public void RotationConstructorLargeRotation() {
    Operation rotOp = new RotationOperation("Rotation", 0, 0, 200, 400);
  }

  @Test(expected = IllegalArgumentException.class)
  public void RotationConstructorSmallRotation() {
    Operation rotOp = new RotationOperation("Rotation", 10, 4, 200, -400);
  }

  @Test(expected = IllegalArgumentException.class)
  public void RotationConstructorInvalidName() {
    Operation rotOp = new RotationOperation("", 0, 0, 200, 30);
  }

  @Test(expected = IllegalArgumentException.class)
  public void RotationConstructorInvalidNegTime() {
    Operation rotOp = new RotationOperation("Rotation", -10, 0, 0, 30);
  }

  @Test(expected = IllegalArgumentException.class)
  public void RotationConstructorInvalidTimes() {
    Operation rotOp = new RotationOperation("Rotation", 10, 0, 0, 30);
  }

  //PositionOperation Constructors
  @Test(expected = IllegalArgumentException.class)
  public void PositionConstructorInvalidX() {
    Operation posOp = new PositionOperation("Position", 0, new Position2D(10, 10), 10,
        new Position2D(-40, 20));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionConstructorInvalidY() {
    Operation posOp = new PositionOperation("Position", 0, new Position2D(10, 10), 10,
        new Position2D(40, -20));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionConstructorInvalidPos() {
    Operation posOp = new PositionOperation("Position", 0, new Position2D(10, -10), 10,
        new Position2D(-40, -20));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionConstructorInvalidName() {
    Operation posOp = new PositionOperation("", 0, new Position2D(10, 10), 10,
        new Position2D(40, 20));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionConstructorInvalidNegTime() {
    Operation posOp = new PositionOperation("Position", -90, new Position2D(10, 10), 10,
        new Position2D(40, 20));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionConstructorInvalidTimes() {
    Operation posOp = new PositionOperation("Position", 10, new Position2D(10, 10), 0,
        new Position2D(40, 20));
  }

  //SizeOperation Constructors
  @Test(expected = IllegalArgumentException.class)
  public void SizeConstructorInvalidWidth() {
    Operation sizeOp = new SizeOperation("Size", 0, new Size(10, 10), 40, new Size(-30, 2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeConstructorInvalidHeight() {
    Operation sizeOp = new SizeOperation("Size", 0, new Size(10, 10), 40, new Size(30, 0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeConstructorInvalidSize() {
    Operation sizeOp = new SizeOperation("Size", 0, new Size(0, -30), 40, new Size(30, 2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeConstructorInvalidName() {
    Operation sizeOp = new SizeOperation("", 0, new Size(10, 10), 40, new Size(30, 2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeConstructorInvalidNegTime() {
    Operation sizeOp = new SizeOperation("Size", -10, new Size(10, 10), 40, new Size(30, 2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeConstructorInvalidTimes() {
    Operation sizeOp = new SizeOperation("Size", 40, new Size(10, 10), 39, new Size(30, 2));
  }

  //ColorOperation Constructors

  @Test(expected = IllegalArgumentException.class)
  public void ColorConstructorNullColor() {
    Operation colorOp = new ColorOperation("Color", 2, null, 5, Color.CYAN);
  }

  @Test(expected = IllegalArgumentException.class)
  public void ColorConstructorInvalidName() {
    Operation colorOp = new ColorOperation("", 2, Color.red, 5, Color.CYAN);
  }

  @Test(expected = IllegalArgumentException.class)
  public void ColorConstructorInvalidNegTime() {
    Operation colorOp = new ColorOperation("Color", -2, Color.red, 5, Color.CYAN);
  }

  @Test(expected = IllegalArgumentException.class)
  public void ColorConstructorInvalidTimes() {
    Operation colorOp = new ColorOperation("Color", 22, Color.red, 5, Color.CYAN);
  }

  // END CONSTRUCTOR TESTS //

  //Rotation Execute
  @Test(expected = IllegalArgumentException.class)
  public void RotationExecuteNullShape() {
    Operation rotOp = new RotationOperation("R", 10, 0, 30, 90);

    rotOp.execute(null, new Size(100, 100));
  }

  @Test
  public void RotationExecuteValid() {
    Shape2D rect = new Rectangle(new Position2D(0, 0), new Size(20, 30), 0, Color.RED);

    Operation rotOp = new RotationOperation("R", 10, 0, 30, 90);

    //rotation before operation
    assertEquals(0, rect.getRotation());

    rotOp.execute(rect, new Size(100, 100));

    //rotation after operation
    assertEquals(90, rect.getRotation());
  }

  //Color execute
  @Test(expected = IllegalArgumentException.class)
  public void ColorExecuteNullShape() {
    Operation colOp = new ColorOperation("R", 10, Color.green, 30, Color.RED);

    colOp.execute(null, new Size(100, 100));
  }

  @Test
  public void ColorExecuteValid() {
    Shape2D rect = new Rectangle(new Position2D(0, 0), new Size(20, 30), 0, Color.RED);

    Operation colOp = new ColorOperation("R", 10, Color.red, 30, Color.green);

    //color before operation
    assertEquals(Color.RED, rect.getColor());

    colOp.execute(rect, new Size(100, 100));

    //color after operation
    assertEquals(Color.GREEN, rect.getColor());
  }

  //Position execute
  @Test(expected = IllegalArgumentException.class)
  public void PositionExecuteNullShape() {
    Operation posOp = new PositionOperation("R", 10, new Position2D(20, 30), 10,
        new Position2D(10, 2));

    posOp.execute(null, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionExecuteOOBX() {
    Operation posOp = new PositionOperation("R", 10, new Position2D(20, 30), 10,
        new Position2D(110, 2));
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(10, 10), 0, Color.BLACK);

    posOp.execute(circle1, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionExecuteOOBY() {
    Operation posOp = new PositionOperation("R", 10, new Position2D(20, 30), 10,
        new Position2D(10, 400));
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(10, 10), 0, Color.BLACK);

    posOp.execute(circle1, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionExecuteOOBXWidth() {
    Operation posOp = new PositionOperation("R", 10, new Position2D(20, 30), 10,
        new Position2D(95, 2));
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(10, 10), 0, Color.BLACK);

    posOp.execute(circle1, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void PositionExecuteOOBYHeight() {
    Operation posOp = new PositionOperation("R", 10, new Position2D(20, 30), 10,
        new Position2D(8, 60));
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(50, 50), 0, Color.BLACK);

    posOp.execute(circle1, new Size(100, 100));
  }

  @Test
  public void PositionExecuteValid() {
    Shape2D rect = new Rectangle(new Position2D(0, 0), new Size(20, 30), 0, Color.RED);

    Operation posOp = new PositionOperation("R", 9, new Position2D(0, 0), 10,
        new Position2D(30, 2));

    //position before operation
    assertEquals(new Position2D(0, 0), rect.getPosition());

    posOp.execute(rect, new Size(100, 100));

    //position after operation
    assertEquals(new Position2D(30, 2), rect.getPosition());
  }

  //Size execute
  @Test(expected = IllegalArgumentException.class)
  public void SizeExecuteNullShape() {
    Operation sizeOp = new SizeOperation("R", 10, new Size(20, 20), 20, new Size(30, 1));

    sizeOp.execute(null, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeExecuteLargeWidth() {
    Shape2D triangle1 = new Triangle(new Position2D(30, 30), new Size(10, 10), 0, Color.blue);
    Operation sizeOp = new SizeOperation("T", 10, new Size(10, 10), 20, new Size(300, 2));

    sizeOp.execute(triangle1, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeExecuteLargeHeight() {
    Shape2D triangle1 = new Triangle(new Position2D(30, 30), new Size(10, 10), 0, Color.blue);
    Operation sizeOp = new SizeOperation("T", 10, new Size(10, 10), 20, new Size(30, 444));

    sizeOp.execute(triangle1, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeExecuteOOBX() {
    Shape2D triangle1 = new Triangle(new Position2D(90, 30), new Size(5, 10), 0, Color.blue);
    Operation sizeOp = new SizeOperation("T", 10, new Size(5, 10), 20, new Size(15, 4));

    sizeOp.execute(triangle1, new Size(100, 100));
  }

  @Test(expected = IllegalArgumentException.class)
  public void SizeExecuteOOBY() {
    Shape2D triangle1 = new Triangle(new Position2D(30, 80), new Size(10, 10), 0, Color.blue);
    Operation sizeOp = new SizeOperation("T", 10, new Size(10, 10), 20, new Size(15, 25));

    sizeOp.execute(triangle1, new Size(100, 100));
  }

  @Test
  public void SizeExecuteValid() {
    Shape2D triangle1 = new Triangle(new Position2D(30, 50), new Size(10, 10), 0, Color.blue);
    Operation sizeOp = new SizeOperation("T", 10, new Size(10, 10), 222, new Size(40, 20));

    //size before operation
    assertEquals(new Size(10, 10), triangle1.getSize());

    sizeOp.execute(triangle1, new Size(100, 100));

    //size after operation
    assertEquals(new Size(40, 20), triangle1.getSize());
  }

  //END OF EXECUTE TESTS//

  //TESTS FOR TIME//
  @Test
  public void testOperationGetDuration() {
    Operation op1 = new ColorOperation("l", 90, Color.blue, 91, Color.pink);
    assertEquals(1, op1.getDuration());

    Operation op2 = new RotationOperation("hi", 0, 2, 6223, -100);
    assertEquals(6223, op2.getDuration());
  }

  @Test
  public void testOperationGetStart() {
    Operation op1 = new ColorOperation("l", 90, Color.blue, 91, Color.pink);
    assertEquals(90, op1.getStartTime());

    Operation op2 = new RotationOperation("hi", 0, 2, 6223, -100);
    assertEquals(0, op2.getStartTime());
  }

  @Test
  public void testOperationGetEnd() {
    Operation op1 = new ColorOperation("l", 90, Color.blue, 91, Color.pink);
    assertEquals(91, op1.getEndTime());

    Operation op2 = new RotationOperation("hi", 0, 2, 6223, -100);
    assertEquals(6223, op2.getEndTime());
  }



}
