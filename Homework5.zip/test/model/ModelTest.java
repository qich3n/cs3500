package model;

import static org.junit.Assert.assertEquals;

import java.awt.Color;

import cs3500.animator.model.AnimationModel;
import cs3500.animator.model.Position2D;
import cs3500.animator.model.SimpleAnimationModel;
import cs3500.animator.model.Size;
import cs3500.animator.model.operations.ColorOperation;
import cs3500.animator.model.operations.Operation;
import cs3500.animator.model.operations.PositionOperation;
import cs3500.animator.model.operations.RotationOperation;
import cs3500.animator.model.shapes.Circle;
import cs3500.animator.model.operations.SizeOperation;
import cs3500.animator.model.shapes.Hexagon;
import cs3500.animator.model.shapes.Oval;
import cs3500.animator.model.shapes.Rectangle;
import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.shapes.Square;
import cs3500.animator.model.shapes.Triangle;
import org.junit.Test;

/**
 * Tests for the public functions in the AnimationModel Interface.
 */
public class ModelTest {
  //TESTS FOR GET WIDTH AND GET HEIGHT//
  @Test (expected = IllegalArgumentException.class)
  public void testInvalidModelWidth() {
    AnimationModel model = new SimpleAnimationModel(0,100);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testInvalidModelHeight() {
    AnimationModel model = new SimpleAnimationModel(99,-10);
  }

  @Test
  public void testGetModelHeight() {
    AnimationModel model = new SimpleAnimationModel(87,100);

    assertEquals(100, model.getModelHeight());
  }

  @Test
  public void testGetModelWidth() {
    AnimationModel model = new SimpleAnimationModel(2,11);

    assertEquals(2, model.getModelWidth());
  }

  //TESTS FOR EXECUTE//
  @Test (expected = IllegalArgumentException.class)
  public void testExecuteOperationsBadShape() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D shape1 = new Triangle(new Position2D(1, 5), new Size(20, 15), 0, Color.black);
    model.addShape("Shape1", shape1);

    Operation moveBadShape = new RotationOperation("BadShape1", 0, 0, 10, 90);

    model.addOperation(moveBadShape);

    model.executeOperations();
  }

  @Test
  public void testExecuteOperationsColor() {
    AnimationModel model = new SimpleAnimationModel(50, 50);
    Shape2D circle1 = new Circle(new Position2D(15, 10), new Size(5, 5), 0, Color.yellow);
    model.addShape("C1", circle1);

    Operation changeC1Green = new ColorOperation("C1", 0, Color.yellow, 10, Color.green);
    model.addOperation(changeC1Green);

    model.executeOperations();
    assertEquals(Color.green, circle1.getColor());

    Operation changeC1Blue = new ColorOperation("C1", 0, Color.green, 10, Color.blue);
    model.addOperation(changeC1Blue);

    model.removeOperation(changeC1Green);
    model.executeOperations();
    assertEquals(Color.blue, circle1.getColor());
  }

  @Test
  public void testExecuteOperationsRotation() {
    AnimationModel model = new SimpleAnimationModel(50, 50);
    Shape2D square1 = new Square(new Position2D(15, 10), new Size(5, 5), 0, Color.yellow);
    model.addShape("S1", square1);

    Operation changeS1Neg90 = new RotationOperation("S1", 0, 0, 10, -90);
    model.addOperation(changeS1Neg90);

    model.executeOperations();
    assertEquals(-90, square1.getRotation());

    Operation changeS1270 = new RotationOperation("S1", 0, -90, 10, 270);
    model.addOperation(changeS1270);

    model.removeOperation(changeS1Neg90);
    model.executeOperations();
    assertEquals(270, square1.getRotation());
  }

  @Test
  public void testExecuteOperationsPosition() {
    AnimationModel model = new SimpleAnimationModel(50, 50);
    Shape2D rect1 = new Square(new Position2D(15, 10), new Size(5, 5), 0, Color.yellow);
    model.addShape("R1", rect1);

    Operation changeR1forward = new PositionOperation("R1", 0,
        new Position2D(15, 10), 10, new Position2D(40, 40));
    model.addOperation(changeR1forward);

    model.executeOperations();
    assertEquals(new Position2D(40, 40), rect1.getPosition());

    Operation changeR1backward = new PositionOperation("R1", 0,
        new Position2D(40, 40), 10, new Position2D(0, 0));
    model.addOperation(changeR1backward);

    model.removeOperation(changeR1forward);
    model.executeOperations();
    assertEquals(new Position2D(0, 0), rect1.getPosition());
  }

  @Test
  public void testExecuteOperationsSize() {
    AnimationModel model = new SimpleAnimationModel(80, 80);
    Shape2D hex1 = new Hexagon(new Position2D(15, 10), new Size(5, 5), 0, Color.yellow);
    model.addShape("H1", hex1);

    Operation changeH1Increase = new SizeOperation("H1", 0, new Size(5, 5), 10, new Size(50, 20));
    model.addOperation(changeH1Increase);

    model.executeOperations();
    assertEquals(new Size(50, 20), hex1.getSize());

    Operation changeH1Decrease = new SizeOperation("H1", 0, new Size(50, 20), 10, new Size(1, 1));
    model.addOperation(changeH1Decrease);

    model.removeOperation(changeH1Increase);
    model.executeOperations();
    assertEquals(new Size(1, 1), hex1.getSize());
  }


  //TESTS FOR ADD SHAPE//

  @Test (expected = IllegalArgumentException.class)
  public void testAddShapeEmptyStringName() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D rect1 = new Rectangle(new Position2D(5, 5), new Size(30, 20), 90, Color.orange);
    model.addShape("", rect1);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testAddShapeNullShape() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    model.addShape("R", null);
  }

  @Test
  public void testAddShapeValid() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D rect1 = new Rectangle(new Position2D(5, 5), new Size(30, 20), 90, Color.orange);
    model.addShape("R", rect1);

    assertEquals("Shape R Rectangle\n\n", model.toString());

    Shape2D rect2 = new Rectangle(new Position2D(55, 20), new Size(3, 3), 0, Color.red);
    model.addShape("R2", rect2);

    assertEquals("Shape R2 Rectangle\n\nShape R Rectangle\n\n", model.toString());

    Shape2D cir1 = new Circle(new Position2D(80, 20), new Size(10, 10), 0, Color.black);
    model.addShape("C1", cir1);

    assertEquals("Shape R2 Rectangle\n\nShape R Rectangle\n\nShape C1 Circle\n\n",
        model.toString());
  }

  //TESTS FOR REMOVE SHAPE//
  @Test (expected = IllegalArgumentException.class)
  public void testRemoveShapeEmptyString() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    model.removeShape("");
  }

  @Test
  public void testRemoveShapeEmptyShapeList() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    model.removeShape("C");

    assertEquals("", model.toString());
  }

  @Test
  public void testRemoveShapeBadLabel() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D rect1 = new Rectangle(new Position2D(5, 5), new Size(30, 20), 90, Color.orange);
    model.addShape("R", rect1);
    Shape2D rect2 = new Rectangle(new Position2D(55, 20), new Size(3, 3), 0, Color.red);
    model.addShape("R2", rect2);
    Shape2D cir1 = new Circle(new Position2D(80, 20), new Size(10, 10), 0, Color.black);
    model.addShape("C1", cir1);

    assertEquals("Shape R2 Rectangle\n\nShape R Rectangle\n\nShape C1 Circle\n\n",
        model.toString());

    model.removeShape("XXX");
    assertEquals("Shape R2 Rectangle\n\nShape R Rectangle\n\nShape C1 Circle\n\n",
        model.toString());
  }

  @Test
  public void testRemoveShapeSuccess() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D rect1 = new Rectangle(new Position2D(5, 5), new Size(30, 20), 90, Color.orange);
    model.addShape("R", rect1);
    Shape2D rect2 = new Rectangle(new Position2D(55, 20), new Size(3, 3), 0, Color.red);
    model.addShape("R2", rect2);
    Shape2D cir1 = new Circle(new Position2D(80, 20), new Size(10, 10), 0, Color.black);
    model.addShape("C1", cir1);

    assertEquals("Shape R2 Rectangle\n\nShape R Rectangle\n\nShape C1 Circle\n\n",
        model.toString());

    model.removeShape("R");
    assertEquals("Shape R2 Rectangle\n\nShape C1 Circle\n\n", model.toString());

    Operation rotateC1 = new RotationOperation("C1", 10, 0, 12, -60);
    model.addOperation(rotateC1);
    model.executeOperations();

    assertEquals("Shape R2 Rectangle\n"
        + "\n"
        + "Shape C1 Circle\n"
        + "motion C1"
        + "\t Time: 10, Type: Circle, Position: (80, 20), Width: 10, Height: 10, Color: (0, 0, 0)"
        + "\t\t"
        + "Time: 10, Type: Circle, Position: (80, 20), Width: 10, Height: 10, Color: (0, 0, 0)\n"
        + "\n", model.toString());

    model.removeShape("C1");

    assertEquals("Shape R2 Rectangle\n\n", model.toString());
  }

  //TESTS FOR ADD OPERATION//
  @Test (expected = IllegalArgumentException.class)
  public void testAddOperationNullOp() {
    AnimationModel model = new SimpleAnimationModel(10, 10);
    Shape2D shape1 = new Oval(new Position2D(2, 2), new Size(2, 2), 0, Color.pink);
    model.addShape("S", shape1);
    Operation move1 = new RotationOperation("S", 0, 0, 10, 90);
    model.addOperation((Operation) null);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOverlapRotation() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(20, 20), 0, Color.RED);
    model.addShape("C", circle1);

    Operation rotationNeg180 = new RotationOperation("C", 4, 0, 22, -180);

    Operation rotationPos180 = new RotationOperation("C", 10, 0, 9, 180);

    model.addOperation(rotationNeg180);
    model.addOperation(rotationPos180);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOverlapColor() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(20, 20), 0, Color.RED);
    model.addShape("C", circle1);

    Operation colorToBlue = new ColorOperation("C", 0, Color.RED, 20, Color.BLUE);

    Operation colorToYellow = new ColorOperation("C", 5, Color.RED, 8, Color.yellow);

    model.addOperation(colorToBlue);
    model.addOperation(colorToYellow);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOverlapPosition() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(20, 20), 0, Color.RED);
    model.addShape("C", circle1);

    Operation posTo5050 = new PositionOperation("C", 0, new Position2D(0, 0),
        20, new Position2D(50, 50));

    Operation posTo1067 = new PositionOperation("C", 5, new Position2D(0, 0),
        8, new Position2D(10, 67));

    model.addOperation(posTo5050);
    model.addOperation(posTo1067);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOverlapSize() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(20, 20), 0, Color.RED);
    model.addShape("C", circle1);

    Operation sizeDouble = new SizeOperation("C", 0, new Size(20, 20), 20, new Size(40, 40));

    Operation sizeHalve = new SizeOperation("C", 6, new Size(20, 20), 20, new Size(10, 10));

    model.addOperation(sizeDouble);
    model.addOperation(sizeHalve);
  }

  @Test
  public void testValidOverlap() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D circle1 = new Circle(new Position2D(10, 10), new Size(20, 20), 0, Color.RED);
    model.addShape("C", circle1);

    Operation sizeDouble = new SizeOperation("C", 0, new Size(20, 20), 20, new Size(40, 40));
    Operation colorToYellow = new ColorOperation("C", 5, Color.RED, 8, Color.yellow);

    model.addOperation(sizeDouble, colorToYellow);
    model.executeOperations();

    assertEquals(Color.yellow, circle1.getColor());
    assertEquals(new Size(40, 40), circle1.getSize());

  }

  //TESTS FOR REMOVE OPERATION//
  @Test (expected = IllegalArgumentException.class)
  public void testRemoveOperationNull() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Operation op = new ColorOperation("col", 0, Color.blue, 10, Color.cyan);
    model.addOperation(op);
    model.removeOperation((Operation) null);
  }

  @Test
  public void testRemoveOperationValid() {
    AnimationModel model = new SimpleAnimationModel(100, 100);
    Shape2D sh1 = new Square(new Position2D(10, 20), new Size(1, 1), 0, Color.blue);
    model.addShape("col", sh1);
    Operation op = new ColorOperation("col", 0, Color.blue, 10, Color.cyan);
    model.addOperation(op);

    model.executeOperations();

    //make sure it doesnt run the operation
    assertEquals("Shape col Square\n"
        + "motion col\t Time: 0, Type: Square, Position: (10, 20), Width: 1, Height: 1, "
        + "Color: (0, 0, 255)\t\tTime: 0, Type: Square, Position: (10, 20), Width: 1, Height: 1, "
        + "Color: (0, 255, 255)\n"
        + "\n", model.toString());

    model = new SimpleAnimationModel(100, 100);
    sh1 = new Square(new Position2D(10, 20), new Size(1, 1), 0, Color.blue);
    model.addShape("col", sh1);
    op = new ColorOperation("col", 0, Color.blue, 10, Color.cyan);
    model.addOperation(op);

    model.removeOperation(op);

    model.executeOperations();

    //make sure it doesnt run the operation
    assertEquals("Shape col Square\n\n", model.toString());

    model = new SimpleAnimationModel(100, 100);
    sh1 = new Square(new Position2D(10, 20), new Size(1, 1), 0, Color.blue);
    model.addShape("col", sh1);
    op = new ColorOperation("col", 0, Color.blue, 10, Color.cyan);
    Operation sizeOp = new SizeOperation("col", 1, new Size(1, 1), 5, new Size(10, 10));
    model.addOperation(op);
    model.addOperation(sizeOp);

    //remove two at the same time
    model.removeOperation(op, sizeOp);

    model.executeOperations();

    //make sure it doesnt run either of the operation
    assertEquals("Shape col Square\n\n", model.toString());
  }

  //TESTS FOR TO STRING//
  @Test
  public void testToStringOneShape() {
    AnimationModel model = new SimpleAnimationModel(100, 100);

    Shape2D shape1 = new Circle(new Position2D(10, 5),
        new Size(5, 5), 90, Color.red);
    model.addShape("Circle1", shape1);

    Operation moveCircle1 =
        new PositionOperation("Circle1", 3, new Position2D(10, 5), 10, new Position2D(30, 15));
    Operation changeCircle1Color =
        new ColorOperation("Circle1", 15, Color.red, 20, Color.blue);

    model.addOperation(moveCircle1);
    model.addOperation(changeCircle1Color);

    model.executeOperations();

    assertEquals("Shape Circle1 Circle\n"
            + "motion Circle1\t Time: 3, Type: Circle, Position: (10, 5), Width: 5, Height: 5, "
            + "Color: (255, 0, 0)\t\tTime: 3, Type: Circle, Position: (30, 15), "
            + "Width: 5, Height: 5, Color: (255, 0, 0)\n"
            + "motion Circle1\t Time: 15, Type: Circle, Position: (30, 15), Width: 5, Height: 5, "
            + "Color: (255, 0, 0)\t\tTime: 15, Type: Circle, Position: (30, 15), Width: 5, "
            + "Height: 5, Color: (0, 0, 255)\n"
            + "\n",
        model.toString());
  }

  @Test
  public void testToStringTwoShape() {
    AnimationModel model = new SimpleAnimationModel(100, 100);

    Shape2D shape1 = new Circle(new Position2D(10, 5),
        new Size(5, 5), 90, Color.red);
    model.addShape("Circle1", shape1);

    Shape2D shape2 = new Rectangle(new Position2D(44, 78), new Size(10, 10),
        0, Color.CYAN);

    model.addShape("Rect1", shape2);

    Operation moveCircle1 =
        new PositionOperation("Circle1", 8, new Position2D(10, 5), 50, new Position2D(30, 10));
    Operation changeCircle1Color =
        new ColorOperation("Circle1", 30, Color.red, 200, Color.PINK);

    Operation moveRect1 = new PositionOperation("Rect1", 10, new Position2D(44, 78),
        15, new Position2D(10, 4));

    model.addOperation(moveCircle1);
    model.addOperation(moveRect1);
    model.addOperation(changeCircle1Color);

    model.executeOperations();

    assertEquals("Shape Circle1 Circle\n"
            + "motion Circle1\t Time: 8, Type: Circle, Position: (10, 5), Width: 5, Height: 5,"
            + " Color: (255, 0, 0)\t\tTime: 8, Type: Circle, Position: (30, 10), Width: 5, "
            + "Height: 5, Color: (255, 0, 0)\n"
            + "motion Circle1\t Time: 30, Type: Circle, Position: (30, 10), Width: 5, Height: 5,"
            + " Color: (255, 0, 0)\t\tTime: 30, Type: Circle, Position: (30, 10), Width: 5, "
            + "Height: 5, Color: (255, 175, 175)\n"
            + "\n"
            + "Shape Rect1 Rectangle\n"
            + "motion Rect1\t Time: 10, Type: Rectangle, Position: (44, 78), Width: 10, Height: 10,"
            + " Color: (0, 255, 255)\t\tTime: 10, Type: Rectangle, Position: (10, 4), Width: 10, "
            + "Height: 10, Color: (0, 255, 255)\n"
            + "\n",
        model.toString());
  }
}
