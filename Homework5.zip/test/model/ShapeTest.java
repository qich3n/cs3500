package model;

import java.awt.Color;
import org.junit.Before;
import org.junit.Test;

import cs3500.animator.model.Position2D;
import cs3500.animator.model.Size;
import cs3500.animator.model.shapes.Circle;
import cs3500.animator.model.shapes.Hexagon;
import cs3500.animator.model.shapes.Oval;
import cs3500.animator.model.shapes.Rectangle;
import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.shapes.Square;
import cs3500.animator.model.shapes.Triangle;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Tests for the methods found in the Shape2D interface.
 */
public class ShapeTest {

  Shape2D circle;
  Shape2D hexagon;
  Shape2D oval;
  Shape2D rectangle;
  Shape2D square;
  Shape2D triangle;

  @Before
  public void setUp() {
    circle = new Circle(new Position2D(10, 11), new Size(5, 5), 0, Color.black);
    hexagon = new Hexagon(new Position2D(20, 22), new Size(6, 2), 10, Color.red);
    oval = new Oval(new Position2D(30, 33), new Size(7, 3), 20, Color.yellow);
    rectangle = new Rectangle(new Position2D(40, 44), new Size(8, 4), 30, Color.blue);
    square = new Square(new Position2D(50, 55), new Size(9, 9), 40, Color.green);
    triangle = new Triangle(new Position2D(60, 66), new Size(4, 6), 50, Color.orange);
  }

  //Testing some of the shapes with bad input in the constructor//
  @Test (expected = IllegalArgumentException.class)
  public void testNullPosCircle() {
    circle = new Oval(null, new Size(5, 5), 0, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullSizeCircle() {
    circle = new Oval(new Position2D(10, 11), null, 0, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullColorCircle() {
    circle = new Oval(new Position2D(10, 11), new Size(5, 5), 0, null);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testLargeRotationCircle() {
    circle = new Oval(new Position2D(10, 11), new Size(5, 5), 360, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testSmallRotationCircle() {
    circle = new Oval(new Position2D(10, 11), new Size(5, 5), -400, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullPosTriangle() {
    triangle = new Triangle(null, new Size(5, 5), 0, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullSizeTriangle() {
    triangle = new Triangle(new Position2D(10, 11), null, 0, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullColorTriangle() {
    triangle = new Triangle(new Position2D(10, 11), new Size(5, 5), 0, null);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testLargeRotationTriangle() {
    triangle = new Triangle(new Position2D(10, 11), new Size(5, 5), 360, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testSmallRotationTriangle() {
    triangle = new Triangle(new Position2D(10, 11), new Size(5, 5), -400, Color.black);
  }


  @Test (expected = IllegalArgumentException.class)
  public void testNullPosRectangle() {
    rectangle = new Rectangle(null, new Size(5, 5), 0, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullSizeRectangle() {
    rectangle = new Rectangle(new Position2D(10, 11), null, 0, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullColorRectangle() {
    rectangle = new Rectangle(new Position2D(10, 11), new Size(5, 5), 0, null);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testLargeRotationRectangle() {
    rectangle = new Rectangle(new Position2D(10, 11), new Size(5, 5), 360, Color.black);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testSmallRotationRectangle() {
    rectangle = new Rectangle(new Position2D(10, 11), new Size(5, 5), -400, Color.black);
  }
  //end of bad input testing//

  @Test
  public void testGetType() {
    assertEquals("Circle", circle.getType());
    assertEquals("Hexagon", hexagon.getType());
    assertEquals("Oval", oval.getType());
    assertEquals("Rectangle", rectangle.getType());
    assertEquals("Square", square.getType());
    assertEquals("Triangle", triangle.getType());
  }

  @Test
  public void testGetColor() {
    assertEquals(Color.black, circle.getColor());
    assertEquals(Color.red, hexagon.getColor());
    assertEquals(Color.yellow, oval.getColor());
    assertEquals(Color.blue, rectangle.getColor());
    assertEquals(Color.green, square.getColor());
    assertEquals(Color.orange, triangle.getColor());
  }

  @Test
  public void testGetPosition() {
    assertEquals(new Position2D(10, 11), circle.getPosition());
    assertEquals(new Position2D(20, 22), hexagon.getPosition());
    assertEquals(new Position2D(30, 33), oval.getPosition());
    assertEquals(new Position2D(40, 44), rectangle.getPosition());
    assertEquals(new Position2D(50, 55), square.getPosition());
    assertEquals(new Position2D(60, 66), triangle.getPosition());
  }

  @Test
  public void testGetWidth() {
    assertEquals(5, circle.getWidth());
    assertEquals(6, hexagon.getWidth());
    assertEquals(7, oval.getWidth());
    assertEquals(8, rectangle.getWidth());
    assertEquals(9, square.getWidth());
    assertEquals(4, triangle.getWidth());
  }

  @Test
  public void testGetHeight() {
    assertEquals(5, circle.getHeight());
    assertEquals(2, hexagon.getHeight());
    assertEquals(3, oval.getHeight());
    assertEquals(4, rectangle.getHeight());
    assertEquals(9, square.getHeight());
    assertEquals(6, triangle.getHeight());
  }

  @Test
  public void testGetRotation() {
    assertEquals(0, circle.getRotation());
    assertEquals(10, hexagon.getRotation());
    assertEquals(20, oval.getRotation());
    assertEquals(30, rectangle.getRotation());
    assertEquals(40, square.getRotation());
    assertEquals(50, triangle.getRotation());
  }

  @Test
  public void testGetSize() {
    assertEquals(new Size(5, 5), circle.getSize());
    assertEquals(new Size(6, 2), hexagon.getSize());
    assertEquals(new Size(7, 3), oval.getSize());
    assertEquals(new Size(8, 4), rectangle.getSize());
    assertEquals(new Size(9, 9), square.getSize());
    assertEquals(new Size(4, 6), triangle.getSize());
  }

  @Test
  public void testSetColor() {
    //assert previous colors before setting them to a new color
    assertEquals(Color.black, circle.getColor());
    assertEquals(Color.red, hexagon.getColor());
    assertEquals(Color.yellow, oval.getColor());
    assertEquals(Color.blue, rectangle.getColor());
    assertEquals(Color.green, square.getColor());
    assertEquals(Color.orange, triangle.getColor());

    //change all colors to cyan
    circle.setColor(Color.cyan);
    hexagon.setColor(Color.cyan);
    oval.setColor(Color.cyan);
    rectangle.setColor(Color.cyan);
    square.setColor(Color.cyan);
    triangle.setColor(Color.cyan);

    //assert that everything has been switched to cyan
    assertEquals(Color.cyan, circle.getColor());
    assertEquals(Color.cyan, hexagon.getColor());
    assertEquals(Color.cyan, oval.getColor());
    assertEquals(Color.cyan, rectangle.getColor());
    assertEquals(Color.cyan, square.getColor());
    assertEquals(Color.cyan, triangle.getColor());
  }

  @Test
  public void testSetPosition() {
    //assert previous positions before setting them to a new position
    assertEquals(new Position2D(10, 11), circle.getPosition());
    assertEquals(new Position2D(20, 22), hexagon.getPosition());
    assertEquals(new Position2D(30, 33), oval.getPosition());
    assertEquals(new Position2D(40, 44), rectangle.getPosition());
    assertEquals(new Position2D(50, 55), square.getPosition());
    assertEquals(new Position2D(60, 66), triangle.getPosition());

    //change all positions to (0, 0)
    circle.setPosition(0, 0);
    hexagon.setPosition(0, 0);
    oval.setPosition(0, 0);
    rectangle.setPosition(0, 0);
    square.setPosition(0, 0);
    triangle.setPosition(0, 0);

    //assert that everything has been switched to (0, 0)
    assertEquals(new Position2D(0, 0), circle.getPosition());
    assertEquals(new Position2D(0, 0), hexagon.getPosition());
    assertEquals(new Position2D(0, 0), oval.getPosition());
    assertEquals(new Position2D(0, 0), rectangle.getPosition());
    assertEquals(new Position2D(0, 0), square.getPosition());
    assertEquals(new Position2D(0, 0), triangle.getPosition());
  }

  @Test
  public void testSetSize() {
    //assert previous sizes before setting them to a new size
    assertEquals(new Size(5, 5), circle.getSize());
    assertEquals(new Size(6, 2), hexagon.getSize());
    assertEquals(new Size(7, 3), oval.getSize());
    assertEquals(new Size(8, 4), rectangle.getSize());
    assertEquals(new Size(9, 9), square.getSize());
    assertEquals(new Size(4, 6), triangle.getSize());

    //change all sizes to (10, 10)
    circle.setSize(10, 10);
    hexagon.setSize(10, 10);
    oval.setSize(10, 10);
    rectangle.setSize(10, 10);
    square.setSize(10, 10);
    triangle.setSize(10, 10);

    //assert that everything has been switched to (0, 0)
    assertEquals(new Size(10, 10), circle.getSize());
    assertEquals(new Size(10, 10), hexagon.getSize());
    assertEquals(new Size(10, 10), oval.getSize());
    assertEquals(new Size(10, 10), rectangle.getSize());
    assertEquals(new Size(10, 10), square.getSize());
    assertEquals(new Size(10, 10), triangle.getSize());
  }

  @Test
  public void testSetRotation() {
    //assert previous rotations before setting them to a new rotation
    assertEquals(0, circle.getRotation());
    assertEquals(10, hexagon.getRotation());
    assertEquals(20, oval.getRotation());
    assertEquals(30, rectangle.getRotation());
    assertEquals(40, square.getRotation());
    assertEquals(50, triangle.getRotation());

    //change all rotations to 100
    circle.setRotation(100);
    hexagon.setRotation(100);
    oval.setRotation(100);
    rectangle.setRotation(100);
    square.setRotation(100);
    triangle.setRotation(100);

    //assert that everything has been switched to (0, 0)
    assertEquals(100, circle.getRotation());
    assertEquals(100, hexagon.getRotation());
    assertEquals(100, oval.getRotation());
    assertEquals(100, rectangle.getRotation());
    assertEquals(100, square.getRotation());
    assertEquals(100, triangle.getRotation());
  }

  @Test
  public void testEquals() {
    assertEquals(new Circle(new Position2D(10, 11),
        new Size(5, 5), 0, Color.black), circle);
    assertEquals(hexagon, new Hexagon(new Position2D(20, 22),
        new Size(6, 2), 10, Color.red));
    assertEquals(oval, new Oval(new Position2D(30, 33),
        new Size(7, 3), 20, Color.yellow));
    assertEquals(rectangle, new Rectangle(new Position2D(40, 44),
        new Size(8, 4), 30, Color.blue));
    assertEquals(square, new Square(new Position2D(50, 55),
        new Size(9, 9), 40, Color.green));
    assertEquals(triangle, new Triangle(new Position2D(60, 66),
        new Size(4, 6), 50, Color.orange));

    //only one element is different in each false test to ensure functionality
    assertNotEquals(new Circle(new Position2D(11, 11),
        new Size(5, 5), 0, Color.black), circle);
    assertNotEquals(hexagon, new Hexagon(new Position2D(20, 22),
        new Size(7, 2), 10, Color.red));
    assertNotEquals(oval, new Oval(new Position2D(30, 33),
        new Size(7, 3), 21, Color.yellow));
    assertNotEquals(rectangle, new Rectangle(new Position2D(40, 44),
        new Size(8, 4), 30, Color.green));
    assertNotEquals(square, new Square(new Position2D(50, 45),
        new Size(9, 9), 40, Color.green));
    assertNotEquals(triangle, new Triangle(new Position2D(60, 66),
        new Size(4, 2), 50, Color.orange));
  }

  @Test
  public void testToString() {
    assertEquals("Type: Circle, Position: (10, 11), Width: 5, Height: 5, "
        + "Color: (0, 0, 0)", circle.toString());
    assertEquals("Type: Hexagon, Position: (20, 22), Width: 6, Height: 2, "
        + "Color: (255, 0, 0)", hexagon.toString());
    assertEquals("Type: Oval, Position: (30, 33), Width: 7, Height: 3, "
        + "Color: (255, 255, 0)", oval.toString());
    assertEquals("Type: Rectangle, Position: (40, 44), Width: 8, Height: 4, "
        + "Color: (0, 0, 255)", rectangle.toString());
    assertEquals("Type: Square, Position: (50, 55), Width: 9, Height: 9, "
        + "Color: (0, 255, 0)", square.toString());
    assertEquals("Type: Triangle, Position: (60, 66), Width: 4, Height: 6, "
        + "Color: (255, 200, 0)", triangle.toString());

  }



}
