package cs3500.animator.model.shapes;

import java.awt.Color;
import java.awt.geom.Point2D;
import java.util.Objects;

import cs3500.animator.model.Position2D;
import cs3500.animator.model.Size;

/**
 * Represents the abstract class of the Shape2D interface.
 * includes implementations of methods common to all shapes.
 */
public abstract class AShape2D implements Shape2D {
  protected int height;
  protected int width;
  protected Position2D position;
  protected Size size;
  protected int rotation;
  protected Color color;

  @Override
  public void setColor(Color newColor) {
    this.color = newColor;
  }

  @Override
  public void setPosition(double newX, double newY) {
    this.position = new Position2D(newX, newY);
  }

  @Override
  public void setSize(int newWidth, int newHeight) {
    this.size = new Size(newWidth, newHeight);
  }

  @Override
  public void setRotation(int newRotation) {
    this.rotation = newRotation;
  }

  @Override
  public Color getColor() {
    return this.color;
  }

  @Override
  public Position2D getPosition() {
    return this.position;
  }

  @Override
  public int getHeight() {
    return this.size.getHeight();
  }

  @Override
  public int getWidth() {
    return this.size.getWidth();
  }

  @Override
  public Size getSize() {
    return this.size;
  }

  @Override
  public int getRotation() {
    return this.rotation;
  }

  @Override
  public void setWidth(int width) {
    if (0 > width) {
      throw new IllegalArgumentException("Cannot have negative width");
    }
    this.width = width;
  }

  @Override
  public void setHeight(int height) {
    if (0 > height) {
      throw new IllegalArgumentException("Cannot have negative height");
    }
    this.height = height;
  }

  @Override
  public void setPosition(Point2D.Double aDouble) {
    Objects.<Point2D>requireNonNull(position);
  }

  @Override
  public void setOrientation(int rotation) {
    this.rotation = rotation;
  }

  @Override
  public boolean equals(Object other) {
    if (!(other instanceof Shape2D shape2)) {
      return false;
    }

    String shape2Type = other.toString().split(" ")[0];
    String shapeType = this.toString().split(" ")[0];

    boolean typeEqual = shapeType.equals(shape2Type);
    boolean colorEqual = this.getColor().equals(shape2.getColor());
    boolean positionEqual = this.getPosition().equals(shape2.getPosition());
    boolean rotationEqual = this.getRotation() == shape2.getRotation();
    boolean heightEqual = this.getHeight() == shape2.getHeight();
    boolean widthEqual = this.getWidth() == shape2.getWidth();

    return typeEqual && colorEqual && positionEqual
        && rotationEqual && heightEqual && widthEqual;
  }

  @Override
  public int hashCode() {
    return this.size.hashCode() + this.rotation + this.color.hashCode() + this.position.hashCode();
  }

  @Override
  public abstract String getType();

  @Override
  public String toString() {
    return String.format("Type: %s, Position: %s, Width: %d, Height: %d, Color: (%d, %d, %d)",
        getType(), getPosition().toString(), getWidth(), getHeight(), getColor().getRed(),
        getColor().getGreen(), getColor().getBlue());
  }

}
