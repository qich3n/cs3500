package cs3500.animator.model.shapes;

import java.awt.Color;

import cs3500.animator.model.Position2D;
import cs3500.animator.model.Size;

/**
 * Represents the Hexagon shape, which is derived from the abstract Shape class.
 */
public class Hexagon extends AShape2D {

  /**
   * Builds the Hexagon shape object with the given parameters and checks them for validity.
   * @param position the position of the shape (positive, not null)
   * @param size the size of the shape (greater than 0, not null)
   * @param rotation the rotation of the shape (within rotation bounds pf -360 to 0)
   *                 a negative rotation indicates clockwise motion, positive is counterclockwise
   * @param color the color of the shape (not null)
   */
  public Hexagon(Position2D position, Size size, int rotation, Color color) {
    if (position == null || size == null || color == null) {
      throw new IllegalArgumentException("Objects cannot be null");
    }
    if (rotation >= 360 || rotation <= -360) {
      throw new IllegalArgumentException("Rotation must be between -360 and 360");
    }

    this.position = position;
    this.size = size;
    this.rotation = rotation;
    this.color = color;
  }

  @Override
  public String getType() {
    return "Hexagon";
  }
}
