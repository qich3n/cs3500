package cs3500.animator.model.shapes;

import java.awt.Color;
import java.awt.geom.Point2D;

import cs3500.animator.model.Position2D;
import cs3500.animator.model.Size;

/**
 * Interface for a 2D shape. Is mutable (for now) and has methods to set the shape parameters and
 * get the current params.
 */
public interface Shape2D {

  /**
   * Sets the color of the shape.
   *
   * @param newColor the color that will be set
   */
  void setColor(Color newColor);

  /**
   * Sets the position of the shape.
   *  @param newX the new x position of the shape (>0)
   * @param newY the new y position of the shape (>0)
   */
  void setPosition(double newX, double newY);

  /**
   * Sets the size of the shape.
   *
   * @param newWidth  the new width of the shape (>0)
   * @param newHeight the new height of the shape (>0)
   */
  void setSize(int newWidth, int newHeight);

  /**
   * Sets the rotation of the shape.
   *
   * @param newRotation the new rotation of the shape (between -360 and 360)
   */
  void setRotation(int newRotation);

  /**
   * Gets the current color of the shape.
   * @return the color
   */
  Color getColor();

  /**
   * Gets the current position of the shape.
   * @return the position
   */
  Position2D getPosition();

  /**
   * Gets the current size of the shape.
   * @return the size
   */
  Size getSize();

  /**
   * Gets the current width of the shape.
   * @return the width (part of the Size)
   */
  int getWidth();

  /**
   * Gets the current height of the shape.
   * @return the height (part of the Size)
   */
  int getHeight();

  /**
   * Gets the current rotation of the shape.
   * @return the rotation
   */
  int getRotation();

  /**
   * Gets the type of shape.
   * @return the type of shape (ex. Circle, Triangle, Rectangle, etc)
   */
  String getType();

  void setWidth(int endingWidth);

  void setHeight(int endingHeight);

  void setPosition(Point2D.Double aDouble);

  /**
   * Sets the orientation of this shape to a given int.
   * @param orientation is the orientation that the shape would be changed to.
   */
  void setOrientation(int orientation);
}
