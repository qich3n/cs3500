package cs3500.animator.model;

import cs3500.animator.model.operations.Operation;
import cs3500.animator.model.shapes.Shape2D;

/**
 * The interface for a generic animation model with its functions.
 *  Includes methods to retrieve info about the model and modify the model.
 */
public interface AnimationModel {

  /**
   * Will perform the model operations.
   * NOTE:: This will later have a time parameter, but skipping now because theres no controller.
   */
  void executeOperations();

  /**
   * Adds the given operations to the operation list of the model.
   *    Checks that there is no overlap
   * @param operations the operation/s that are to be added to the model
   */
  void addOperation(Operation... operations);

  /**
   * Removes the given operations from the operation list of the model.
   * @param operations the operation/s that are to be removed from the model
   */
  void removeOperation(Operation... operations);

  /**
   * Returns the width of the window of the animation.
   * Will change this so that shapes can exist outside of the window without being seen.
   * @return the width
   */
  int getModelWidth();

  /**
   * Returns the height of the window of the animation.
   * Will change this so that shapes can exist outside of the window without being seen.
   * @return the height
   */
  int getModelHeight();

  /**
   * Adds a shape to the model's shape list it is operating on.
   * @param label The name of the shape (for finding)
   * @param shape the shape itself (Shape2D)
   */

  void addShape(String label, Shape2D shape);

  /**
   * removes the shape from the model's list of shapes.
   * @param label the name of the shape to remove
   */
  void removeShape(String label);

}
