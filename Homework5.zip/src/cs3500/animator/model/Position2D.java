package cs3500.animator.model;

import java.awt.geom.Point2D;
import java.util.Objects;

// This class was taken from the Class Notes: Module Command Pattern.

/**
 * This class represents a 2D position.
 */
public final class Position2D extends Point2D {
  private double x;
  private double y;

  /**
   * Initialize this object to the specified position.
   * @param x the x coordinate
   * @param y the y coordinate
   */
  public Position2D(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Copy constructor for the Position2D object.
   * @param v the copy Position2D object.
   */
  public Position2D(Position2D v) {
    this(v.x, v.y);
  }

  /**
   * Gets the positions current x position.
   * @return the x coordinate
   */
  public double getX() {
    return x;
  }

  /**
   * Gets the positions current y position.
   * @return the y coordinate
   */
  public double getY() {
    return y;
  }

  @Override
  public void setLocation(double x, double y) {
    this.x = x;
    this.y = y;
  }

  @Override
  public String toString() {
    return String.format("(%d, %d)", this.x, this.y);
  }

  @Override
  public boolean equals(Object a) {
    if (this == a) {
      return true;
    }
    if (!(a instanceof Position2D)) {
      return false;
    }

    Position2D that = (Position2D) a;

    return ((Math.abs(this.x - that.x) < 0.01) && (Math.abs(this.y - that.y) < 0.01));
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.x, this.y);
  }
}