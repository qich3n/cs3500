package cs3500.animator.model.operations;

import cs3500.animator.model.Size;
import cs3500.animator.model.shapes.Shape2D;

/**
 * Interface for the Operations in the model.
 * Includes methods for getting the information from the operation and executing the operation
 *  itself.
 */
public interface Operation {

  /**
   * Executes the specific command/operation as told by the implemented class.
   * @param shape the shape the operation will be made on
   * @param modelSize the bounds of the model window (change later?)
   */
  void execute(Shape2D shape, Size modelSize);

  /**
   * Gets the name of the shape the operation is operating on.
   * @return the shape's name
   */
  String getName();

  /**
   * Gets the total duration of this operation.
   * @return the duration
   */
  int getDuration();

  /**
   * Gets the given start time of the operation.
   * @return start time
   */
  int getStartTime();

  /**
   * Gets the given end time of the operation.
   * @return end time
   */
  int getEndTime();

}
