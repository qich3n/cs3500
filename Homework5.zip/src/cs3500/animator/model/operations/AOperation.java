package cs3500.animator.model.operations;

import cs3500.animator.model.Size;
import cs3500.animator.model.shapes.Shape2D;

/**
 * The abstract class of the Operation interface.
 * Contains operations that are common to all operations.
 */
public abstract class AOperation implements Operation {
  protected String shapeName;
  protected int startTime;
  protected int endTime;

  protected int calcValueInc(double start, double end, int duration) {
    double diff = end - start;
    return Math.floorDiv((int) diff, duration);
  }

  @Override
  public abstract void execute(Shape2D shape, Size modelSize);

  @Override
  public String getName() {
    return shapeName;
  }

  @Override
  public int getDuration() {
    return this.endTime - this.startTime;
  }

  @Override
  public int getStartTime() {
    return this.startTime;
  }

  @Override
  public int getEndTime() {
    return this.endTime;
  }
}
