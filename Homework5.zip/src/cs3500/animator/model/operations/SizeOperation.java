package cs3500.animator.model.operations;

import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.Size;

/**
 * The class representing operations performed on the size of the shape.
 */
public class SizeOperation extends AOperation {
  private final Size startSize;
  private final Size endSize;

  /**
   * Constructs the Size operation object with the given parameters and checks for valid values.
   * @param name The name of the shape to be operated on (cannot be empty).
   * @param startTime when the operation will begin (non-negative adn less than endTime)
   * @param startSize the size of the shape at the start time
   *                      (checks that this matches with shape, not null, greater than 0)
   * @param endTime when the operation will end (non-negative and greater than startTime).
   * @param endSize the size of the shape at the end time
   *                    (not null, greater than 0)
   */
  public SizeOperation(String name, int startTime, Size startSize, int endTime, Size endSize) {
    if (startSize.getWidth() <= 0 || startSize.getHeight() <= 0
        || endSize.getWidth() <= 0 || endSize.getHeight() <= 0) {
      throw new IllegalArgumentException("Size cannot be negative");
    } else if (name == null || name.equals("")) {
      throw new IllegalArgumentException("Name cannot be empty");
    } else if (startTime < 0 || endTime < 0) {
      throw new IllegalArgumentException("Times must be greater than 0");
    } else if (startTime >= endTime) {
      throw new IllegalArgumentException("Start time must be less than end time");
    }

    this.startTime = startTime;
    this.endTime = endTime;
    this.shapeName = name;
    this.endSize = endSize;
    this.startSize = startSize;

  }

  @Override
  public void execute(Shape2D shape, Size modelSize) {
    if (shape == null) {
      throw new IllegalArgumentException("Shape cannot be null");
    }
    if (!shape.getSize().equals(startSize)) {
      throw new IllegalArgumentException("Sizes do not match");
    }
    if (modelSize.getWidth() < shape.getPosition().getX() + this.endSize.getWidth()
        || modelSize.getHeight() < shape.getPosition().getY() + this.endSize.getHeight()) {
      throw new IllegalArgumentException("Size change out of bounds");
    }

    for (int t = 0; t < getDuration(); t++) {
      int newWidth = shape.getWidth()
          + calcValueInc(shape.getWidth(), endSize.getWidth(), getDuration() - t);
      int newHeight = shape.getHeight()
          + calcValueInc(shape.getHeight(), endSize.getHeight(), getDuration() - t);
      shape.setSize(newWidth, newHeight);
    }
  }
}
