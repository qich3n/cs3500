package cs3500.animator.model.operations;

import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.Size;

/**
 * The class representing operations performed on the rotation of the shape.
 */
public class RotationOperation extends AOperation {
  private final int startRotation;
  private final int endRotation;

  /**
   * Constructs the rotation operation object with the given parameters and checks for valid values.
   * @param name The name of the shape to be operated on (cannot be empty).
   * @param startTime when the operation will begin (non-negative adn less than endTime)
   * @param startRotation the rotation of the shape at the start time
   *                      (checks that this matches with shape, in rotation bounds)
   * @param endTime when the operation will end (non-negative and greater than startTime).
   * @param endRotation the rotation of the shape at the end time
   *                    (in rotation bounds)
   */
  public RotationOperation(String name, int startTime, int startRotation,
      int endTime, int endRotation) {
    if (startRotation <= -360 || startRotation >= 360
        || endRotation <= -360 || endRotation >= 360) {
      throw new IllegalArgumentException("Rotation out of bounds");
    } else if (name == null || name.equals("")) {
      throw new IllegalArgumentException("Name cannot be empty");
    } else if (startTime < 0 || endTime < 0) {
      throw new IllegalArgumentException("Times must be greater than 0");
    } else if (startTime >= endTime) {
      throw new IllegalArgumentException("Start time must be less than end time");
    }

    this.startTime = startTime;
    this.endTime = endTime;
    this.startRotation = startRotation;
    this.endRotation = endRotation;
    this.shapeName = name;
  }

  @Override
  public void execute(Shape2D shape, Size modelSize) {
    if (shape == null) {
      throw new IllegalArgumentException("Shape cannot be null");
    }

    if (this.startRotation != shape.getRotation()) {
      throw new IllegalArgumentException("Rotations do not match");
    }

    for (int t = 0; t < getDuration(); t++) {
      int newRotation = shape.getRotation()
          + calcValueInc(shape.getRotation(), endRotation, getDuration() - t);
      shape.setRotation(newRotation);
    }
  }
}
