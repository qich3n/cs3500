package cs3500.animator.model.operations;

import java.awt.Color;

import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.Size;

/**
 * The class representing operations performed on the color of the shape.
 */
public class ColorOperation extends AOperation {
  private final Color startColor;
  private final Color endColor;

  /**
   * Constructs the color operation object with the given parameters and checks for valid values.
   * @param name The name of the shape to be operated on (cannot be empty).
   * @param startTime when the operation will begin (non-negative adn less than endTime)
   * @param startColor the color of the shape at the start time(checks that this matches with shape)
   * @param endTime when the operation will end (non-negative and greater than startTime).
   * @param endColor the color of the shape at the end time
   */
  public ColorOperation(String name, int startTime, Color startColor,
      int endTime, Color endColor) {
    if (startColor == null || endColor == null) {
      throw new IllegalArgumentException("Color cannot be null");
    } else if (name == null || name.equals("")) {
      throw new IllegalArgumentException("Name cannot be empty");
    } else if (startTime < 0 || endTime < 0) {
      throw new IllegalArgumentException("Times must be greater than 0");
    } else if (startTime >= endTime) {
      throw new IllegalArgumentException("Start time must be less than end time");
    }

    this.startTime = startTime;
    this.endTime = endTime;
    this.shapeName = name;
    this.startColor = startColor;
    this.endColor = endColor;
  }

  @Override
  public void execute(Shape2D shape, Size modelSize) {
    if (shape == null) {
      throw new IllegalArgumentException("Shape cannot be null");
    }

    if (!this.startColor.equals(shape.getColor())) {
      throw new IllegalArgumentException("Colors do not match");
    }
    shape.setColor(this.endColor);
  }

}
