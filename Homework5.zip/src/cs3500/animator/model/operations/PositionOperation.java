package cs3500.animator.model.operations;

import cs3500.animator.model.Position2D;
import cs3500.animator.model.shapes.Shape2D;
import cs3500.animator.model.Size;

// add getPosition into here
/**
 * The class representing operations performed on the position of the shape.
 */
public class PositionOperation extends AOperation {
  private final Position2D startPos;
  private final Position2D endPos;

  /**
   * Constructs the position operation object with the given parameters and checks for valid values.
   * @param name The name of the shape to be operated on (cannot be empty).
   * @param startTime when the operation will begin (non-negative adn less than endTime)
   * @param startPos the position of the shape at start time
   *                 (checks that this matches with shape, positive, not null)
   * @param endTime when the operation will end (non-negative and greater than startTime).
   * @param endPos the position of the shape at the end time (positive, not null)
   */
  public PositionOperation(String name, int startTime, Position2D startPos,
      int endTime, Position2D endPos) {
    if (startPos.getX() < 0 || startPos.getY() < 0 || endPos.getX() < 0 || endPos.getY() < 0) {
      throw new IllegalArgumentException("Position cannot be negative");
    } else if (name == null || name.equals("")) {
      throw new IllegalArgumentException("Name cannot be empty");
    } else if (startTime < 0 || endTime < 0) {
      throw new IllegalArgumentException("Times must be greater than 0");
    } else if (startTime >= endTime) {
      throw new IllegalArgumentException("Start time must be less than end time");
    }

    this.startTime = startTime;
    this.endTime = endTime;
    this.shapeName = name;
    this.startPos = startPos;
    this.endPos = endPos;
  }

  @Override
  public void execute(Shape2D shape, Size modelSize) {
    if (shape == null) {
      throw new IllegalArgumentException("Shape cannot be null");
    }

    if (!this.startPos.equals(shape.getPosition())) {
      throw new IllegalArgumentException("Positions do not match");
    }

    if (modelSize.getWidth() < this.endPos.getX() + shape.getWidth()
        || modelSize.getHeight() < this.endPos.getY() + shape.getHeight()) {
      throw new IllegalArgumentException("Movement out of bounds");
    }

    for (int t = 0; t < getDuration(); t++) {
      double newX = shape.getPosition().getX()
          + calcValueInc(shape.getPosition().getX(), this.endPos.getX(), getDuration() - t);
      double newY = shape.getPosition().getY()
          + calcValueInc(shape.getPosition().getY(), this.endPos.getY(), getDuration() - t);
      shape.setPosition(newX, newY);
    }
  }

}
