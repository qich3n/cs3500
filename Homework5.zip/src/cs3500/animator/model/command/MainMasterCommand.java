package cs3500.animator.model.command;

import cs3500.animator.model.shapes.Shape2D;

/**
 * The MainMasterCommand class which contains the orientations of the shapes.
 */
public class MainMasterCommand extends MainCommand implements IAnimationRotate {
  private final int startOrientation;
  private final int endOrientation;

  /**
   * Constructor for main master command that initializes the fields for the command for a shape.
   *
   * @param type represents the type of command.
   * @param startTime   represents starting time of a command.
   * @param x1   represents the starting x coordinate.
   * @param y1   represents the starting y coordinate.
   * @param initialWidth   represents the starting width.
   * @param initialHeight   represents the starting height.
   * @param startingOrientation   represents the starting orientation.
   * @param rgbRed1   represents the starting value for red.
   * @param rgbGreen1   represents the starting value for green.
   * @param rgbBlue1   represents the starting value for blue.
   * @param endTime   represents the ending time of a command.
   * @param x2   represents the ending x coordinate.
   * @param y2   represents the ending y coordinate.
   * @param endWidth   represents the ending width.
   * @param endHeight   represents the ending height.
   * @param endingOrientation   represents the ending orientation.
   * @param rgbRed2   represents the ending red value.
   * @param rgbGreen2   represents the ending green value.
   * @param rgbBlue2   represents the ending blue value.
   * @throws IllegalArgumentException when the start time or end time , or if width or
   *                                  height is negative at any point, or if the start time is after
   *                                  the end time.
   */
  public MainMasterCommand(String type, int startTime, int x1, int y1, int initialWidth,
                           int initialHeight, int startingOrientation, int rgbRed1, int rgbGreen1,
                           int rgbBlue1, int endTime, int x2, int y2, int endWidth, int endHeight,
                           int endingOrientation, int rgbRed2, int rgbGreen2, int rgbBlue2)
          throws IllegalArgumentException {
    super(type, startTime, x1, y1, initialWidth, initialHeight, rgbRed1, rgbGreen1, rgbBlue1,
            endTime, x2, y2, endWidth, endHeight, rgbRed2, rgbGreen2, rgbBlue2);
    this.startOrientation = startingOrientation;
    this.endOrientation = endingOrientation;
  }

  @Override
  public Shape2D setState(int time, Shape2D shape) {
    shape.setOrientation(this.findPointAt(time, this.startOrientation, this.endOrientation));
    return super.setState(time, shape);
  }

  /**
   * Obtains the orientation of the shape.
   *
   * @return an int represents the orientation in degrees
   */
  @Override
  public int obtainStartOrientation() {
    return this.startOrientation;
  }

  /**
   * Obtains the orientation of the shape.
   *
   * @return an int represents the orientation in degrees
   */
  @Override
  public int obtainEndOrientation() {
    return this.endOrientation;
  }
}