package cs3500.animator.model.command;

import java.awt.*;
import java.awt.geom.Point2D;

import cs3500.animator.model.shapes.Shape2D;

/**
 * Represents a command on unique Shape, contains the starting values and ending values of the
 * shape fields.
 */
public class MainCommand implements IAnimationCommand {
  private final String type;
  protected final int startTime;
  private final int StartingX;
  private final int StartingY;
  private final int StartingWidth;
  private final int StartingHeight;
  private final Color StartingColor;

  protected final int endTime;
  private final int endingX;
  private final int endingY;
  private final int endingWidth;
  private final int endingHeight;
  private final Color endingColor;

  /**
   * Constructor for master command that initalizes each of the fields of the command.
   * @param type represents what type of command this is.
   * @param startTime represents starting time of the command.
   * @param x1 represents the starting x coordinate.
   * @param y1 represents the starting y coordinate.
   * @param startWidth represents the starting width of the shape.
   * @param startHeight represents the starting height of the shape.
   * @param rgbRed1 represents the starting value for red of the shape.
   * @param rgbGreen1 represents the starting value for green of the shape.
   * @param rgbBlue1 represents the starting value for blue of the shape.
   * @param endTime represents the ending time of the command.
   * @param x2 represents the ending x coordinate.
   * @param y2 represents the ending y coordinate.
   * @param endWidth represents the ending width of the shape.
   * @param endHeight represents the ending height of the shape.
   * @param rgbRed2 represents the ending red value for the shape.
   * @param rgbGreen2 represents the ending green value for the shape.
   * @param rgbBlue2 represents the ending blue value for the shape.
   * @throws IllegalArgumentException If the start time or end time, or the width or height is
   *                                  negative, or if the start time is after the end time.
   */
  public MainCommand(String type, int startTime, int x1, int y1, int startWidth, int startHeight,
                     int rgbRed1, int rgbGreen1, int rgbBlue1, int endTime, int x2, int y2,
                     int endWidth, int endHeight, int rgbRed2, int rgbGreen2, int rgbBlue2)
          throws IllegalArgumentException {
    if (startTime > endTime || startTime < 0) {
      throw new IllegalArgumentException("Invalid start/end time.");
    }
    if (startWidth < 0 || endWidth < 0) {
      throw new IllegalArgumentException("Width cant be negative.");
    }
    if (startHeight < 0 || endHeight < 0) {
      throw new IllegalArgumentException("Height cant be negative.");
    }
    if (rgbRed1 < 0 || rgbRed2 < 0) {
      throw new IllegalArgumentException("RGB values has to be within [0, 255].");
    } else if (rgbGreen1 < 0 || rgbGreen2 < 0) {
      throw new IllegalArgumentException("RGB values has to be within [0, 255].");
    } else if (rgbBlue1 < 0 || rgbBlue2 < 0
            || rgbRed1 > 255 || rgbRed2 > 255) {
      throw new IllegalArgumentException("RGB values has to be within [0, 255].");
    } else if (rgbGreen1 > 255 || rgbGreen2 > 255) {
      throw new IllegalArgumentException("RGB values has to be within [0, 255].");
    } else if (rgbBlue1 > 255 || rgbBlue2 > 255) {
      throw new IllegalArgumentException("RGB values has to be within [0, 255].");
    }
    this.type = type;
    this.startTime = startTime;
    this.StartingX = x1;
    this.StartingY = y1;
    this.StartingWidth = startWidth;
    this.StartingHeight = startHeight;
    this.StartingColor = new Color(rgbRed1, rgbGreen1, rgbBlue1);
    this.endTime = endTime;
    this.endingX = x2;
    this.endingY = y2;
    this.endingWidth = endWidth;
    this.endingHeight = endHeight;
    this.endingColor = new Color(rgbRed2, rgbGreen2, rgbBlue2);
  }

  @Override
  public String getType() {
    return this.type;
  }

  @Override
  public int getStartTime() {
    return this.startTime;
  }

  @Override
  public int getStartX() {
    return StartingX;
  }

  @Override
  public int getStartY() {
    return StartingY;
  }

  @Override
  public int getStartWidth() {
    return StartingWidth;
  }

  @Override
  public int getStartHeight() {
    return StartingHeight;
  }

  @Override
  public Color getStartColor() {
    return StartingColor;
  }

  @Override
  public int getEndTime() {
    return this.endTime;
  }

  @Override
  public int getEndX() {
    return endingX;
  }

  @Override
  public int getEndY() {
    return endingY;
  }

  @Override
  public int getEndWidth() {
    return endingWidth;
  }

  @Override
  public int getEndHeight() {
    return endingHeight;
  }

  @Override
  public Color getEndColor() {
    return endingColor;
  }

  /**
   * Mutates shape to its state at the given time. Throws an exception if the time is not within 
   * the start and end times of the command.
   *
   * @param time  represents ticks.
   * @param shape Starting shape before a command has been run.
   * @return TwoDShape that is the mutated shape.
   */
  @Override
  public Shape2D setState(int time, Shape2D shape) {
    if (time < this.startTime || time > this.endTime) {
      throw new IllegalArgumentException("Invalid time");
    }
    else if (this.startTime == this.endTime) {
      shape.setPosition(new Point2D.Double(this.endingX, this.endingY));
      shape.setWidth(this.endingWidth);
      shape.setHeight(this.endingHeight);
      shape.setColor(this.endingColor);
      return shape;
    }

    int newXVal = this.findPointAt(time, this.StartingX, this.endingX);
    int newYVal = this.findPointAt(time, this.StartingY, this.endingY);
    shape.setPosition(new Point2D.Double(newXVal, newYVal));

    shape.setWidth(this.findPointAt(time, this.StartingWidth, this.endingWidth));
    shape.setHeight(this.findPointAt(time, this.StartingHeight, this.endingHeight));

    int newRedVal = this.findPointAt(time, this.StartingColor.getRed(), this.endingColor.getRed());
    int newGreenVal = this.findPointAt(time, this.StartingColor.getGreen(),
            this.endingColor.getGreen());
    int newBlueVal = this.findPointAt(time, this.StartingColor.getBlue(),
            this.endingColor.getBlue());
    shape.setColor(new Color(newRedVal, newGreenVal, newBlueVal));

    return shape;
  }

  //calculates midpoint of position of the shape 
  protected int findPointAt(int time, int startValue, int endValue) {
    if (this.startTime == this.endTime) {
      return endValue;
    }
    else {
      int i = ((endValue - startValue) * (time - this.startTime))
              / (this.endTime - this.startTime) + startValue;
      return i;
    }
  }
}