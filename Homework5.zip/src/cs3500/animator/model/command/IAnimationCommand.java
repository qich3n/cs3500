package cs3500.animator.model.command;

import cs3500.animator.model.shapes.Shape2D;

/**
 * Represents a command on a shape during the animation.
 */
public interface IAnimationCommand extends IAnimationReadCommand {
  /**
   * Mutates the shape to its state at the given time after performing command.
   * Throws an exception if the time is not within the start and end times of command.
   * @param time represents ticks
   * @param shape represents shape
   * @return TwoDShape that is the mutated.
   */
  Shape2D setState(int time, Shape2D shape);
}