package cs3500.animator.model.command;

/**
 * Represents a command that supports rotating shapes.
 */
public interface IAnimationRotate extends IAnimationRotateCommand, IAnimationCommand {
}
