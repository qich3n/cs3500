package cs3500.animator.model.command;

/**
 * Represents command that can rotate a shape (Read-only).
 */
public interface IAnimationRotateCommand extends IAnimationReadCommand {
  /**
   * Command which obtains the starting orientation.
   * @return int which represents the orientation in degrees
   */
  int obtainStartOrientation();

  /**
   * Command that obtains the ending orientation of shape.
   * @return int which represents the orientation in degrees
   */
  int obtainEndOrientation();
}
