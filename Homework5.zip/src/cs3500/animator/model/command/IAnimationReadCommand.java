package cs3500.animator.model.command;

import java.awt.*;

/**
 * Represents a command on a shape during animation.
 */
public interface IAnimationReadCommand {
 
  /**
   * Obtains start time of command (tick that the command begins on the shape).
   * @return int that represents the tick where the command begins.
   */
  int getStartTime();

  /**
   * Obtains end time of command (the tick that the command ends on the shape).
   * @return int that represents the tick where the command begins.
   */
  int getEndTime();

  /**
   * Obtains the type of the command in String form.
   * @return a String that represents the type of command.
   */
  String getType();

  /**
   * Obtains the starting X value of shape as int.
   * @return the starting X value of the shape.
   */
  int getStartX();

  /**
   * Obtains the starting Y value of the shape as int.
   * @return the starting Y value of the shape.
   */
  int getStartY();

  /**
   * Obtains the starting width of the shape as int.
   * @return the starting width value of the shape.
   */
  int getStartWidth();

  /**
   * Obtains the starting height of the shape as int.
   * @return the starting height value of the shape.
   */
  int getStartHeight();

  /**
   * Obtains the starting color of the shape.
   * @return the starting color of the shape.
   */
  Color getStartColor();

  /**
   * Obtains the ending X value of shape as int.
   * @return the ending X value of the shape.
   */
  int getEndX();

  /**
   * Obtains the ending Y value of shape as int.
   * @return the ending Y value of the shape.
   */
  int getEndY();

  /**
   * Obtains the ending width of shape as int.
   * @return the ending width value of the shape.
   */
  int getEndWidth();

  /**
   * Obtains the ending height value of shape as int.
   * @return the ending height value of the shape.
   */
  int getEndHeight();

  /**
   * Obtains the ending color of shape as int.
   * @return the ending color of shape.
   */
  Color getEndColor();
}