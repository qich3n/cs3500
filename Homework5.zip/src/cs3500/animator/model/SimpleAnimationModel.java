package cs3500.animator.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cs3500.animator.model.operations.Operation;
import cs3500.animator.model.shapes.Shape2D;

/**
 * The simple model for the animation.
 * Keeps track of the operations within the animation, the shapes in the animation,
 *  and handles executing the operations on the shapes.
 */
public class SimpleAnimationModel implements AnimationModel {
  //NOTE: The size may be removed depending on how the view / controller end up handling the window
  private final Size modelSize;
  private final Map<String, Shape2D> shapeList;
  private final List<Operation> operations;
  private final Map<String, String> log;

  /**
   * Builds the simple model for the animation and sets the default values.
   * @param modelWidth the given width of the model
   * @param modelHeight the given height of the model
   */
  public SimpleAnimationModel(int modelWidth, int modelHeight) {
    if (modelWidth <= 0 || modelHeight <= 0) {
      throw new IllegalArgumentException("Window size cannot be less than 0");
    }
    this.modelSize = new Size(modelWidth, modelHeight);
    this.shapeList = new HashMap<>();
    this.log = new HashMap<>();
    this.operations = new ArrayList<>();
  }

  private boolean timeOverlap(int t1Start, int t1End, int t2Start, int t2End) {
    return (t2Start < t1End && t2Start > t1Start) || (t2End < t1End && t2End > t1Start)
        || (t1Start < t2End && t1Start > t2Start) || (t1End < t2End && t1End > t2Start);
  }

  @Override
  public void addOperation(Operation... ops) {
    for (Operation o : ops) {
      if (o == null) {
        throw new IllegalArgumentException("Operation cannot be null");
      }
      //first : check for operation shape against list
      for (Operation oExisting : operations) {
        if (o.getName().equals(oExisting.getName())) {
          if (timeOverlap(o.getStartTime(), o.getEndTime(),
              oExisting.getStartTime(), oExisting.getEndTime())) {
            if (o.getClass().equals(oExisting.getClass())) {
              throw new IllegalArgumentException("Operations cannot operate on the same "
                  + "shape feature at the same time");
            }
          }
        }
      }

      operations.add(o);
    }
  }

  @Override
  public void removeOperation(Operation... ops) {
    for (Operation op : ops) {
      if (op == null) {
        throw new IllegalArgumentException("Operation cannot be null");
      }
      for (int ii = 0; ii < operations.size(); ii++) {
        if (op.equals(operations.get(ii))) {
          operations.remove(ii);
          ii--;
        }
      }
    }
  }

  @Override
  public void executeOperations() {
    //NOTE: right now, there is no checking for the current time. In future assignments, this
    //      method will take in a tick parameter so that only the operations with that start time
    //      execute. This will be implemented once the controller is included.

    //check that the operations arent null and get the shape
    for (Operation op : operations) {
      if (op == null ) {
        throw new IllegalArgumentException();
      }

      boolean foundName = false;
      for (Map.Entry<String, Shape2D> entry: shapeList.entrySet()) {
        if (op.getName().equals(entry.getKey())) {
          String before = log.get(entry.getKey()) + (String.format("motion %s\t Time: %d, %s\t\t",
              entry.getKey(), op.getStartTime(), entry.getValue().toString()));

          log.put(entry.getKey(), before);
          op.execute(entry.getValue(), this.modelSize);

          foundName = true;
          String after = log.get(entry.getKey())
              + (String.format("Time: %d, %s\n", op.getStartTime(), entry.getValue().toString()));

          log.put(entry.getKey(), after);
          break;
        }
      }
      if (!foundName) {
        //if we got here, then the shape doesnt exist in our list
        throw new IllegalArgumentException("Could not find shape");
      }

    }

  }

  @Override
  public int getModelWidth() {
    return this.modelSize.getWidth();
  }

  @Override
  public int getModelHeight() {
    return this.modelSize.getHeight();
  }

  @Override
  public void addShape(String label, Shape2D shape) {
    if (label.equals("") || shape == null) {
      throw new IllegalArgumentException("Added shape arguments cannot be null");
    }
    shapeList.put(label, shape);
    log.put(label, String.format("Shape %s %s\n", label, shape.getType()));
  }

  @Override
  public void removeShape(String label) {
    if (label.equals("")) {
      throw new IllegalArgumentException("Shape name cannot be empty");
    }
    shapeList.remove(label);
    log.remove(label);

    //NOTE: this for loop cannot be a for each because then it doesnt remove properly
    for (int ii = 0; ii < operations.size(); ii++) {
      if (operations.get(ii).getName().equals(label)) {
        removeOperation(operations.get(ii));
      }
    }
  }

  @Override
  public String toString() {
    StringBuilder logBuild = new StringBuilder();

    for (Map.Entry<String, String> entry: log.entrySet()) {
      logBuild.append(String.format("%s\n", entry.getValue()));
    }

    return logBuild.toString();
  }


}
