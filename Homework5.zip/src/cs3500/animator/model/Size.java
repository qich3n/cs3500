package cs3500.animator.model;

/**
 * Represents a size type for better organization of sizes.
 * The height and width must be greater than 0.
 */
public class Size {
  public final int width;
  public final int height;

  /**
   * Builds the size object with the given width and height (must be more than 0).
   * @param width the width for the size
   * @param height the height for the size
   */
  public Size(int width, int height) {
    if (width <= 0 || height <= 0) {
      throw new IllegalArgumentException("Size cannot be 0 or negative");
    }
    this.height = height;
    this.width = width;
  }

  public int getWidth() {
    return this.width;
  }

  public int getHeight() {
    return this.height;
  }

  @Override
  public boolean equals(Object other) {
    if (!(other instanceof Size)) {
      return false;
    }

    Size otherSize = (Size) other;

    return (this.getWidth() == otherSize.getWidth()) && (this.getHeight() == otherSize.getHeight());
  }

  @Override
  public int hashCode() {
    return getHeight() + getWidth();
  }
}
