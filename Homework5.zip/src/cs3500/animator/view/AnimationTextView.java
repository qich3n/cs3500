package cs3500.animator.view;

import java.io.StringWriter;

import cs3500.animator.model.AnimationModel;
import cs3500.animator.model.command.IAnimationRotateCommand;

/**
 * Represents a text description of the given animation.
 */
public class AnimationTextView implements IAnimationTextView {
  private Appendable out;
  private AnimationModel model;

  /**
   * Constructor for AnimationTextView which takes the model to convert it into a string.
   *
   * @param model is the model for which the AnimationTextView will create a constructor for.
   */
  public AnimationTextView(AnimationModel model) {
    this.model = model;
    out = new StringWriter();
  }

  @Override
  public String getText() {
    return this.out.toString();
  }

  @Override
  public void playAnimation() {

    StringBuilder output = new StringBuilder();
    for (var entry : this.model.obtainCommand().entrySet()) {
      IAnimationShape shape = this.model.obtainShape().get(entry.getKey());
      output.append("Shape ").append(entry.getKey()).append(" ").append(shape.getShapeType())
              .append("\n");
      for (IAnimationRotateCommand command : entry.getValue()) {
        StringBuilder temp = new StringBuilder(command.getType()).append(" ");
        temp.append(entry.getKey());
        temp.append(" ");
        temp.append(command.getStartTime());
        temp.append(" ");
        temp.append(command.getStartX());
        temp.append(" ");
        temp.append(command.getStartY());
        temp.append(" ");
        temp.append(command.getStartWidth());
        temp.append(" ");
        temp.append(command.getStartHeight());
        temp.append(" ");
        temp.append(command.obtainStartOrientation());
        temp.append(" ");
        temp.append(command.getStartColor().getRed());
        temp.append(" ");
        temp.append(command.getStartColor().getGreen());
        temp.append(" ");
        temp.append(command.getStartColor().getBlue());
        temp.append("    ");
        temp.append(command.getEndTime());
        temp.append(" ");
        temp.append(command.getEndX());
        temp.append(" ");
        for (int i : new int[]{command.getEndY(), command.getEndWidth(), command.getEndHeight(),
                command.obtainEndOrientation(), command.getEndColor().getRed(),
                command.getEndColor().getGreen()}) {
          temp.append(i);
          temp.append(" ");
        }
        temp.append(command.getEndColor().getBlue());
        temp.append("\n");
        output.append(temp);
      }
      output.append("\n");
    }

    if (output.length() != 0) {
      output.delete(output.length() - 2, output.length());
    }
    out = output;
  }
}