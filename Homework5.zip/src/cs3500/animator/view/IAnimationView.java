package cs3500.animator.view;

/**
 * Represents the display for the animation.
 */
public interface IAnimationView {
  /**
   * Plays the animation using the view that is currently initialized.
   */
  void playAnimation();
}