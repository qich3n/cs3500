package cs3500.animator.view;

/**
 * Represents the views which display the animation by appending it to an appendable.
 */
public interface IAnimationTextView extends IAnimationView {
  /**
   * Gets the texts which represents the animation.
   * @return String which displays description for the animation.
   */
  String getText();
}